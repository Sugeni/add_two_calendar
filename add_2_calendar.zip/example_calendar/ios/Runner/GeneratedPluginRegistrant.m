//
//  Generated file. Do not edit.
//

#import "GeneratedPluginRegistrant.h"
#import <add_2_calendar/Add2CalendarPlugin.h>

@implementation GeneratedPluginRegistrant

+ (void)registerWithRegistry:(NSObject<FlutterPluginRegistry>*)registry {
  [Add2CalendarPlugin registerWithRegistrar:[registry registrarForPlugin:@"Add2CalendarPlugin"]];
}

@end
